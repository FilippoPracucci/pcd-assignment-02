package pcd.ass02.reactive;

/**
 * @author Bedeschi Federica   federica.bedeschi4@studio.unibo.it
 * @author Pracucci Filippo    filippo.pracucci@studio.unibo.it
 */
public class Test {

    public static void main(String[] args) {
        new Controller();
    }
}
