package pcd.ass02.reactive;

import pcd.ass02.util.ClassDepsReport;

public interface RxClassDepsReport extends ClassDepsReport {

    String getPath();

}
