package pcd.ass02.example.foopack;

public class B {

}
