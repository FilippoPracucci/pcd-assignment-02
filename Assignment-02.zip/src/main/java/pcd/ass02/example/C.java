package pcd.ass02.example;

public class C {

}
