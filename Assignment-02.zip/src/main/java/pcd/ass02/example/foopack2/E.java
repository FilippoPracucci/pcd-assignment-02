package pcd.ass02.example.foopack2;

public class E {

}
