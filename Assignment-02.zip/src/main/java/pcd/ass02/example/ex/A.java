package pcd.ass02.example.ex;

public class A {

}
