package pcd.ass02.example;

import pcd.ass02.example.ex.*;
import pcd.ass02.example.foopack.D;
import pcd.ass02.example.foopack2.E;

public class MyClass {

	A field;
	
	pcd.ass02.example.foopack.B m(E e) {
		C a;
		new D().m();
		return null;
	}
}
